
package dentaire;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import java.sql.SQLException;

public class ManagePatient extends javax.swing.JFrame {
    
    public ManagePatient() {
        initComponents();
        selectPatient();
    }
    

    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        patientCNI = new javax.swing.JTextField();
        patientPrenom = new javax.swing.JTextField();
        nTel = new javax.swing.JTextField();
        b_ajout = new javax.swing.JButton();
        b_mod = new javax.swing.JButton();
        b_suppr = new javax.swing.JButton();
        b_effac = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablePatient = new javax.swing.JTable();
        typeService = new javax.swing.JComboBox<>();
        patientNom = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        paiment = new javax.swing.JTextField();
        dateRendezVous = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        manage_employee1 = new javax.swing.JLabel();
        manage_patient = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        rendez_vous = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        paiement = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        manage_employee = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 102, 102));
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(0, 102, 102));

        jLabel1.setFont(new java.awt.Font("SansSerif", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cabinet dentaire");

        jLabel14.setIcon(new javax.swing.ImageIcon("C:\\Users\\YouSsef-pc\\Downloads\\icons8-denture-48.png")); // NOI18N

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setForeground(new java.awt.Color(0, 102, 102));

        jLabel2.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 102));
        jLabel2.setText("CNI");

        jLabel3.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 102));
        jLabel3.setText("Prénom");

        jLabel4.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 102));
        jLabel4.setText("N° tél");

        jLabel5.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 102, 102));
        jLabel5.setText("type de service");

        patientCNI.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        patientCNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                patientCNIActionPerformed(evt);
            }
        });

        patientPrenom.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        patientPrenom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                patientPrenomActionPerformed(evt);
            }
        });

        nTel.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        nTel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nTelActionPerformed(evt);
            }
        });

        b_ajout.setBackground(new java.awt.Color(0, 102, 102));
        b_ajout.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        b_ajout.setForeground(new java.awt.Color(255, 255, 255));
        b_ajout.setText("Ajouter");
        b_ajout.setBorder(null);
        b_ajout.setBorderPainted(false);
        b_ajout.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        b_ajout.setFocusPainted(false);
        b_ajout.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        b_ajout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                b_ajoutMouseClicked(evt);
            }
        });
        b_ajout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_ajoutActionPerformed(evt);
            }
        });

        b_mod.setBackground(new java.awt.Color(0, 102, 102));
        b_mod.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        b_mod.setForeground(new java.awt.Color(255, 255, 255));
        b_mod.setText("Modifiè");
        b_mod.setBorder(null);
        b_mod.setBorderPainted(false);

        b_suppr.setBackground(new java.awt.Color(0, 102, 102));
        b_suppr.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        b_suppr.setForeground(new java.awt.Color(255, 255, 255));
        b_suppr.setText("Supprimer");
        b_suppr.setBorder(null);
        b_suppr.setBorderPainted(false);
        b_suppr.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                b_supprMouseClicked(evt);
            }
        });

        b_effac.setBackground(new java.awt.Color(0, 102, 102));
        b_effac.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        b_effac.setForeground(new java.awt.Color(255, 255, 255));
        b_effac.setText("Effacer");
        b_effac.setBorder(null);
        b_effac.setBorderPainted(false);
        b_effac.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                b_effacMouseClicked(evt);
            }
        });

        tablePatient.setAutoCreateRowSorter(true);
        tablePatient.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        tablePatient.setForeground(new java.awt.Color(0, 102, 102));
        tablePatient.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CNI", "Nom", "Prénom", "N° tél", "Type de service", "Paiment", "Date de rendez vous"
            }
        ));
        tablePatient.setShowGrid(true);
        tablePatient.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablePatientMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablePatient);

        typeService.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        typeService.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        patientNom.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        patientNom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                patientNomActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 102, 102));
        jLabel6.setText("Nom");

        jLabel8.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 102, 102));
        jLabel8.setText("Paiment");

        paiment.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N

        dateRendezVous.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        dateRendezVous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dateRendezVousActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("SansSerif", 0, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 102, 102));
        jLabel7.setText("Date de rendez-vous");

        jPanel1.setBackground(new java.awt.Color(0, 146, 142));

        manage_employee1.setFont(new java.awt.Font("SansSerif", 3, 24)); // NOI18N
        manage_employee1.setForeground(new java.awt.Color(255, 255, 255));
        manage_employee1.setText("Gestion de patients");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(manage_employee1)
                .addGap(366, 366, 366))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addComponent(manage_employee1)
                .addGap(32, 32, 32))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel6)
                    .addComponent(jLabel3)
                    .addComponent(jLabel7))
                .addGap(31, 31, 31)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(dateRendezVous, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(patientCNI, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(patientNom, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(patientPrenom, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 251, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(paiment, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nTel, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(typeService, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(60, 60, 60))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(b_ajout, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(b_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(b_suppr, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(b_effac, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(241, 241, 241))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(patientCNI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(patientNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(patientPrenom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(typeService, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(paiment, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))))
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(dateRendezVous, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(b_ajout, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b_suppr, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b_effac, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                .addContainerGap())
        );

        manage_patient.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        manage_patient.setForeground(new java.awt.Color(255, 255, 255));
        manage_patient.setText("Patients");

        jLabel10.setForeground(new java.awt.Color(204, 204, 204));
        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\YouSsef-pc\\Downloads\\icons8-out-patient-department-24.png")); // NOI18N

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\YouSsef-pc\\Downloads\\icons8-2012-24.png")); // NOI18N

        rendez_vous.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        rendez_vous.setForeground(new java.awt.Color(255, 255, 255));
        rendez_vous.setText("Rendez-vous");
        rendez_vous.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rendez_vousMouseClicked(evt);
            }
        });

        jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\YouSsef-pc\\Downloads\\icons8-online-payment-24.png")); // NOI18N

        paiement.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        paiement.setForeground(new java.awt.Color(255, 255, 255));
        paiement.setText("Paiement");

        jLabel13.setIcon(new javax.swing.ImageIcon("C:\\Users\\YouSsef-pc\\Downloads\\icons8-teamwork-24.png")); // NOI18N

        manage_employee.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        manage_employee.setForeground(new java.awt.Color(255, 255, 255));
        manage_employee.setText("Employes");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel14)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(8, 8, 8)
                                .addComponent(manage_patient))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(8, 8, 8)
                                .addComponent(rendez_vous))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(8, 8, 8)
                                .addComponent(paiement))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(manage_employee)))))
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel1)))
                .addGap(115, 115, 115)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(manage_employee)
                    .addComponent(jLabel13))
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(manage_patient, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rendez_vous, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(paiement, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void patientCNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_patientCNIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_patientCNIActionPerformed

    private void patientPrenomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_patientPrenomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_patientPrenomActionPerformed

    private void nTelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nTelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nTelActionPerformed

    private void b_ajoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_ajoutActionPerformed
  
    }//GEN-LAST:event_b_ajoutActionPerformed

    private void patientNomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_patientNomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_patientNomActionPerformed

    private void dateRendezVousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dateRendezVousActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dateRendezVousActionPerformed

    public void selectPatient(){
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "you123");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from PATIENT");
            tablePatient.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    private void b_ajoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b_ajoutMouseClicked
        try{
            if (patientCNI.getText().isEmpty() && patientNom.getText().isEmpty() && patientPrenom.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this,"S'il vous plait entrer tout les information ");
            }else{
                Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "you123");
                Statement st = con.createStatement();
                PreparedStatement add = con.prepareStatement("INSERT INTO PATIENT VALUES (?,?,?,?,?,?,?)");
                add.setString(1,patientCNI.getText());
                add.setString(2,patientNom.getText());
                add.setString(3,patientPrenom.getText());
                add.setInt(4,Integer.valueOf(nTel.getText()));
                add.setString(5,typeService.getSelectedItem().toString());
                add.setInt(6,Integer.valueOf(paiment.getText()));
                add.setString(7, dateRendezVous.getText());
                int a = add.executeUpdate();
                if (a>0) {
                    JOptionPane.showMessageDialog(this,"Patient ajouté");
                }
                selectPatient();
                con.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_b_ajoutMouseClicked

    private void b_effacMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b_effacMouseClicked
        // TODO add your handling code here:
        patientCNI.setText("");
        patientNom.setText("");
        patientPrenom.setText("");
        nTel.setText("");
        typeService.setSelectedItem("");
        paiment.setText("");
        dateRendezVous.setText("");
    }//GEN-LAST:event_b_effacMouseClicked

    private void b_supprMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b_supprMouseClicked
        // TODO add your handling code here:
        if(patientCNI.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Entrer le patient qui est supprimer");
        }else {
            
            try{
                Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "you123");   
                String query = "DELETE FROM PATIENT WHERE P_ID="+patientCNI.getText();
                Statement sup = con.createStatement();
                //PreparedStatement supp = con.prepareStatement(query);
                sup.executeUpdate(query);
                selectPatient();
                JOptionPane.showMessageDialog(this,"le patient est supprimer");
            }catch(Exception e){
                e.printStackTrace();
            }
        
        
        }
    }//GEN-LAST:event_b_supprMouseClicked

    private void tablePatientMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablePatientMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)tablePatient.getModel();
        int index = tablePatient.getSelectedRow();
        patientCNI.setText(model.getValueAt(index, 0).toString());
        patientNom.setText(model.getValueAt(index, 1).toString());
        patientPrenom.setText(model.getValueAt(index, 2).toString());
        nTel.setText(model.getValueAt(index, 3).toString());
        typeService.setSelectedItem(model.getValueAt(index, 4).toString());
        paiment.setText(model.getValueAt(index, 5).toString());
        dateRendezVous.setText(model.getValueAt(index, 6).toString());
    }//GEN-LAST:event_tablePatientMouseClicked

    private void rendez_vousMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rendez_vousMouseClicked
        // TODO add your handling code here:
        RendezVous rv = new RendezVous();
        setVisible(false);
        rv.setVisible(true);
    }//GEN-LAST:event_rendez_vousMouseClicked

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagePatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManagePatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManagePatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManagePatient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManagePatient().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_ajout;
    private javax.swing.JButton b_effac;
    private javax.swing.JButton b_mod;
    private javax.swing.JButton b_suppr;
    private javax.swing.JTextField dateRendezVous;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel manage_employee;
    private javax.swing.JLabel manage_employee1;
    private javax.swing.JLabel manage_patient;
    private javax.swing.JTextField nTel;
    private javax.swing.JLabel paiement;
    private javax.swing.JTextField paiment;
    private javax.swing.JTextField patientCNI;
    private javax.swing.JTextField patientNom;
    private javax.swing.JTextField patientPrenom;
    private javax.swing.JLabel rendez_vous;
    private javax.swing.JTable tablePatient;
    private javax.swing.JComboBox<String> typeService;
    // End of variables declaration//GEN-END:variables
}
